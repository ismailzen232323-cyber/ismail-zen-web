LAN CONNECT — SIAP UPLOAD

1. GitHub Pages: upload semua isi folder ini ke repository, pastikan index.html di root. Settings > Pages > Deploy from branch > main > /root.
2. Netlify: upload folder ini atau hasil ZIP.
3. Video: masukkan dua MP4 ke folder video dengan nama:
   tutorial-merangkai-kabel-lan.mp4
   tutorial-sharing-data-peer-to-peer.mp4
4. PPTX asli ada di materi/. Preview website menggunakan PDF karena browser tidak menjalankan PPTX secara native.
